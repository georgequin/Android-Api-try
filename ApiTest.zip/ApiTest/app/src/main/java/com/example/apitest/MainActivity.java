package com.example.apitest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private TextView surname, matNo;
    private ImageView Profile;
    private RecyclerView mRecyclerView;
    private RecyclerViewAdapter mRecyclerViewAdapter;
    private ArrayList<ReturnItem> returnList;
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        surname = findViewById(R.id.creator);
        Profile = findViewById(R.id.ImageView);
//        matNo = findViewById(R.id.text2);
        mRecyclerView = findViewById(R.id.Recycler_view);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        returnList = new ArrayList<>();
        requestQueue = Volley.newRequestQueue(this);
        ParseJSON();
    }

    private void ParseJSON(){
        String URL = "https://dog.ceo/api/breeds/image/random";
     //   String URL2 = "http://10.255.14.89:8000/rfid/api/";


        try {
            final JsonObjectRequest Request;
            Request = new JsonObjectRequest(com.android.volley.Request.Method.GET, URL, null,
                new Response.Listener<JSONObject>(){
                @Override
                public void onResponse(JSONObject Response){
                    try {

                        String status = Response.getString("status");
                        //surname.setText(status);
                        String ImgURL = Response.getString("message");
                        int like = 10;

                        returnList.add(new ReturnItem(ImgURL,status,like));

                        //Picasso.get().load(ImgURL).into(Profile);
                      //  matNo.setText(ImgURL);

    //                    JSONArray jsonObject = Response.getJSONArray("student_name");
    //                    for (int i = 0; i< jsonObject.length();i++){
    //                        JSONObject StudentName = jsonObject.getJSONObject(i);
    //                        Surname = StudentName.getString("surname");
    //                        surname.setText(Surname);
    //                        String MatNo = StudentName.getString("matric_number");
    //                        matNo.setText(MatNo);
    //
    //                    }

    //                    String Surname = jsonObject.getJ("surname");


                        //String name = jsonObject.getJSONArray();
                        //System.out.println(name);

                        //String name = jsonObject.toString();
                        //surname.setText(name);
                        //Log.d("api result: ",name);
    //                    JSONArray jsonArray = Response.ge tJSONArray("student_name");
    //                    for (int i=0; i< jsonArray.length(); i++){
    //                        JSONObject surnsme = jsonArray.getJSONObject(i);
    //                        String SURNAME = surnsme.getString("surname");
    //
    //                        System.out.println(SURNAME);
    //                        surname.setText(name);
    //                    }
                    } catch (JSONException e) {
                        e.printStackTrace();
                   }

                    mRecyclerViewAdapter = new RecyclerViewAdapter(MainActivity.this, returnList);
                    mRecyclerView.setAdapter(mRecyclerViewAdapter);
                }
            },new Response.ErrorListener(){

                @Override
                public void onErrorResponse(VolleyError error) {
                    error.printStackTrace();

                }
            });

            requestQueue.add(Request);
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to load", Toast.LENGTH_SHORT).show();
        }


    }

    private void JSON2(){

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.refresh, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        int MenuItemThatWasSelected = item.getItemId();
        if (MenuItemThatWasSelected == R.id.action_refresh){
            ParseJSON();
            Toast.makeText(this, "Refresh Clicked", Toast.LENGTH_SHORT).show();
        }
        return super.onOptionsItemSelected(item);

    }
}
