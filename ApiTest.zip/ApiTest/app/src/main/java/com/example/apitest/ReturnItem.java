package com.example.apitest;

public class ReturnItem {
    private String mImageUrl;
    private String mCreator;
    private int mLikes;
    //private String Surname;

    public ReturnItem(String ImageUrl, String Creator, int Likes) {
        //Surname = surname;
        mImageUrl = ImageUrl;
        mCreator = Creator;
        mLikes = Likes;
    }

    public String getmImageUrl(){
        return mImageUrl;
    }

    public String getmCreator(){
        return mCreator;
    }

    public int getmLikes(){
        return mLikes;
    }
}
