package com.example.apitest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    Context mContext;
    ArrayList<ReturnItem> mReturnList;

    public RecyclerViewAdapter(Context context, ArrayList<ReturnItem> ReturnList){
        mContext = context;
        mReturnList = ReturnList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(mContext).inflate(R.layout.item_view, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ReturnItem CurrentItem = mReturnList.get(position);

        String ImageUrl = CurrentItem.getmImageUrl();
        String Creator = CurrentItem.getmCreator();
        int Likes = CurrentItem.getmLikes();

        holder.mLikes.setText("likes: " + Likes);
        holder.mCreator.setText(Creator);

        //Picasso.with().load(ImageUrl).fit().centerInside().into(holder.mImageView);
        Picasso.get().load(ImageUrl).fit().centerInside().into(holder.mImageView);


    }

    @Override
    public int getItemCount() {
        return mReturnList.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        public ImageView mImageView;
        public TextView mCreator;
        public TextView mLikes;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            mImageView = itemView.findViewById(R.id.ImageView);
            mCreator = itemView.findViewById(R.id.creator);
            mLikes = itemView.findViewById(R.id.likes);
        }
    }
}
